#!/bin/bash
# TaikoHub Opener - richtet den lokalen Launcher ein (oeffnet installierte PWAs
# statt Browser). Muss nur einmal ausgefuehrt werden.
set -e
echo "======================================"
echo "   TaikoHub Opener wird installiert"
echo "======================================"
echo

NODE="$(command -v node || true)"
if [ -z "$NODE" ]; then
  echo "FEHLER: Node.js fehlt. Bitte einmalig von https://nodejs.org installieren,"
  echo "dann diese Datei erneut oeffnen."
  read -p "Enter zum Schliessen..." _
  exit 1
fi

DIR="$HOME/Library/Application Support/TaikoHub"
mkdir -p "$DIR"
echo "Lade Launcher..."
curl -fsSL "https://raw.githubusercontent.com/Propman4k/TaikoHub/main/launcher.mjs" -o "$DIR/launcher.mjs"

PLIST="$HOME/Library/LaunchAgents/com.taikonauten.taikohub-launcher.plist"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.taikonauten.taikohub-launcher</string>
  <key>ProgramArguments</key>
  <array><string>$NODE</string><string>$DIR/launcher.mjs</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$DIR/launcher.log</string>
  <key>StandardErrorPath</key><string>$DIR/launcher.log</string>
</dict>
</plist>
PL

launchctl bootout "gui/$(id -u)/com.taikonauten.taikohub-launcher" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
sleep 1
echo
if curl -fsS http://127.0.0.1:7890/ >/dev/null 2>&1; then
  echo "FERTIG! Der TaikoHub Opener laeuft. Fenster kann geschlossen werden."
else
  echo "Installiert. Falls es nicht sofort geht: Mac einmal neu starten."
fi
read -p "Enter zum Schliessen..." _
